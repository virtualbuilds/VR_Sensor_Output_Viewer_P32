﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO.Ports;
using System.Collections;
using System.Collections.Generic;
using System.Globalization;
using System.Windows;
using System.Windows.Forms.DataVisualization;

namespace WaveformViewer {

    public partial class Form1 : Form {

        public Form1() {
            InitializeComponent();
            try {
                string[] ports = new string[SerialPort.GetPortNames().Length];
                Dictionary<string, string> friendlyPorts = BuildPortNameHash(SerialPort.GetPortNames());
                Font dropDownFont = comComboBox.Font;
                Graphics g = comComboBox.CreateGraphics();
                int newDropDownWidth = 0;
                int dropDownWidth = comComboBox.DropDownWidth;
                int i = 0;
                foreach (KeyValuePair<string, string> kvp in friendlyPorts) {
                    ports[i] = " " + kvp.Value;
                    newDropDownWidth = (int)g.MeasureString(kvp.Value, dropDownFont).Width;
                    i++;
                    if (dropDownWidth < newDropDownWidth)
                        dropDownWidth = newDropDownWidth;
                }
                comComboBox.DropDownWidth = dropDownWidth;
                comComboBox.DataSource = ports;
                comComboBox.SelectedIndex = 0;
                serialPort1.BaudRate = baud_rate;
                serialPort1.Encoding = System.Text.Encoding.GetEncoding(28591);
            } catch (Exception ex) {
                Console.WriteLine("Serial Port not detected!");
            }
            panel1.Location = new System.Drawing.Point(this.ClientSize.Width / 2 - panel1.Size.Width / 2, 19);



            chart1.Series.Clear();
            for (int i = 0; i < pdSeries.Length; i++) {
                pdSeries[i] = new System.Windows.Forms.DataVisualization.Charting.Series("PD" + i);
                pdSeries[i].ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.StepLine;
                //pdSeries[i].XValueType = System.Windows.Forms.DataVisualization.Charting.ChartValueType.UInt32; //time
                pdSeries[i].XValueType = System.Windows.Forms.DataVisualization.Charting.ChartValueType.Double; //time

                pdSeriesx[i] = new System.Windows.Forms.DataVisualization.Charting.Series("PDx" + i);
                pdSeriesx[i].ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.StepLine;
                //pdSeriesx[i].XValueType = System.Windows.Forms.DataVisualization.Charting.ChartValueType.UInt32; //time
                pdSeriesx[i].XValueType = System.Windows.Forms.DataVisualization.Charting.ChartValueType.Double; //time
                chart1.Series.Add(pdSeriesx[i]);
                chart1.Series["PDx" + i].Enabled = false;
                pdSeriesx[i].Color = Color.Red;

                pdSeriesy[i] = new System.Windows.Forms.DataVisualization.Charting.Series("PDy" + i);
                pdSeriesy[i].ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.StepLine;
                //pdSeries[i].XValueType = System.Windows.Forms.DataVisualization.Charting.ChartValueType.UInt32; //time
                pdSeriesy[i].XValueType = System.Windows.Forms.DataVisualization.Charting.ChartValueType.Double; //time
                chart1.Series.Add(pdSeriesy[i]);
                chart1.Series["PDy" + i].Enabled = false;
                pdSeriesy[i].Color = Color.Blue;

                chart1.Series.Add(pdSeries[i]);
                pdColor[i] = chart1.Series["PD" + i].Color;
            }
            chart1.Series.Add(nopSeries);
            chart1.Series["No sensors detected"].Enabled = false;


            //chart1.ChartAreas["ChartArea2"].CursorX.IsUserSelectionEnabled = true;   //zoom selection
            //chart1.ChartAreas["ChartArea2"].CursorX.Interval = 1 / 48000000;
            //chart1.ChartAreas["ChartArea2"].AxisX.MajorGrid.LineColor = Color.Gainsboro;
            //chart1.ChartAreas["ChartArea2"].AxisY.MajorGrid.LineColor = Color.Gainsboro;
            //chart1.ChartAreas["ChartArea2"].AxisX.ScaleView.Zoomable = true;
            //chart1.ChartAreas["ChartArea2"].AxisX.LabelStyle.Format = "#.######";

            chart1.ChartAreas["ChartArea1"].CursorX.IsUserSelectionEnabled = true;   //zoom selection
            chart1.ChartAreas["ChartArea1"].CursorX.Interval = 1 / 48000000;
            chart1.ChartAreas["ChartArea1"].AxisX.MajorGrid.LineColor = Color.Gainsboro;
            chart1.ChartAreas["ChartArea1"].AxisY.MajorGrid.LineColor = Color.Gainsboro;
            chart1.ChartAreas["ChartArea1"].AxisX.ScaleView.Zoomable = true;
            chart1.ChartAreas["ChartArea1"].AxisX.Title = "time (μs)";
            chart1.ChartAreas["ChartArea1"].AxisY.Title = "photodiode logic state";
            chart1.ChartAreas["ChartArea1"].AxisX.LabelStyle.Format = "#.######";
        }

        private void Form1_FormClosing(object sernder, FormClosingEventArgs e) {
            serialPort1.Close();
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e) {
            serialPort1.Close();
            Environment.Exit(0);
        }

        private void comComboBox_SelectedIndexChanged(object sender, EventArgs e) {
            serialPort1.Close();
            serialPort1.Dispose();
            string temp = (comComboBox.Text).Split('(', ')')[1];
            serialPort1.PortName = temp;
            serialPort1.WriteTimeout = 1000;   // 30 seconds
        }

        private void comComboBox_Click(object sender, MouseEventArgs e) {
            /**** Initialize serial port combox with default ****/
            string[] ports = new string[SerialPort.GetPortNames().Length];
            Dictionary<string, string> friendlyPorts = BuildPortNameHash(SerialPort.GetPortNames());
            Font dropDownFont = comComboBox.Font;
            Graphics g = comComboBox.CreateGraphics();
            int newDropDownWidth = 0;
            int dropDownWidth = comComboBox.DropDownWidth;
            int i = 0;
            foreach (KeyValuePair<string, string> kvp in friendlyPorts) {
                ports[i] = " " + kvp.Value;
                newDropDownWidth = (int)g.MeasureString(kvp.Value, dropDownFont).Width;
                i++;
                if (dropDownWidth < newDropDownWidth)
                    dropDownWidth = newDropDownWidth;
            }
            comComboBox.DropDownWidth = dropDownWidth;
            comComboBox.DataSource = ports;
        }

        private void serial_Write(string text) {
            if (comComboBox.Text == "Select a port")                             // check com port is chosen
            {
                MessageBox.Show("Please choose COM port", "System Configure Information",
                                 MessageBoxButtons.OK, MessageBoxIcon.Warning); return;
            }

            try {
                if (!serialPort1.IsOpen)
                    serialPort1.Open();
                serialPort1.Write(text);
            } catch (Exception ex) //UnauthorizedAccessException
              {
                MessageBox.Show("Error: Serial Port Communication \nOriginal error: " + ex.Message,
                                "System Configure Information",
                                 MessageBoxButtons.OK,
                                 MessageBoxIcon.Warning);
                if (serialPort1.IsOpen)
                    serialPort1.Close();
                return;
            }
        }

        private void serial_Char(char letter) {
            if (comComboBox.Text == "Select a port")                             // check com port is chosen
            {
                MessageBox.Show("Please choose COM port", "System Configure Information",
                                 MessageBoxButtons.OK, MessageBoxIcon.Warning); return;
            }

            try {
                if (!serialPort1.IsOpen)
                    serialPort1.Open();
                serialPort1.Write(letter.ToString());
            } catch (Exception ex) //UnauthorizedAccessException
              {
                MessageBox.Show("Error: Serial Port Communication \nOriginal error: " + ex.Message,
                                "System Configure Information",
                                 MessageBoxButtons.OK,
                                 MessageBoxIcon.Warning);
                if (serialPort1.IsOpen)
                    serialPort1.Close();
                return;
            }
        }

        private void DataReceivedHandler(object sender, SerialDataReceivedEventArgs e) {
            rxData.Append(serialPort1.ReadExisting());
            //Console.WriteLine(serialPort1.ReadExisting());
        }

        private void testButton_Click(object sender, EventArgs e) {

            try {
                Cursor.Current = Cursors.WaitCursor;
                runningLabel.Visible = true;
                //bool firstPeriod = false;
                //bool secondPeriod = false;
                //bool thirdPeriod = false;

                double sample = Convert.ToDouble(sampleTextBox.Text);
                double dsleep = sample * 1100;
                sample = sample * 48000000;
                int isample = (int)sample;
                isample = (isample >> 22);

                serial_Char((char)(isample + 1));////////////////////original
                serial_Char((char)0);////////////////////original
                Console.WriteLine("smaple " + isample);

                if (serialPort1.IsOpen) {/////////

                    System.Threading.Thread.Sleep((int)dsleep);////////////////////original
                    serialPort1.Close();
                    //System.Threading.Thread.Sleep((int)dsleep);
                    //Console.WriteLine((int)dsleep % 500);
                    updateChart();
                }////////////////////original
                runningLabel.Text = "Running...";
                runningLabel.Visible = false;
                Cursor.Current = Cursors.Arrow;
            } catch (Exception ex) //UnauthorizedAccessException
              {
                Console.WriteLine("Execption Messgage: " + ex.StackTrace.ToString());
                MessageBox.Show("Error: Data compilation \nOriginal error: " + ex.Message, "System Configure Information",
                                 MessageBoxButtons.OK, MessageBoxIcon.Warning);

            }
        }

        private void updateChart() {
            //chart1.Series.Clear();
            for (int i = 0; i < 32; i++) {
                first_timestampr[i] = true;
                first_timestampf[i] = true;
                last_timestampr[i] = 0;
                last_timestampf[i] = 0;
                xRotor[i] = false;
                sensorDetected[i] = false;
            }


            //first_timestampr = Enumerable.Repeat(true, first_timestampr.Length).ToArray();
            //first_timestampf = Enumerable.Repeat(true, first_timestampf.Length).ToArray();

            //chart1.Palette = System.Windows.Forms.DataVisualization.Charting.ChartColorPalette.Pastel;

            nSensorsDetected = 0;
            char[] lastBit = new char[32];
            UInt32 zero = 0;
            UInt32 temp = 0;
            //UInt32[] temp = new UInt32[32];
            double tempPoint = 0;
            bool zeroTime = false;
            rxDataStream = rxData.ToString().Split(new string[] { "\n", "\n\r", "\r\n" }, StringSplitOptions.None);
            Console.WriteLine(rxData);
            //Console.WriteLine(rxDataStream.Length);
            for (int i = 0; i < rxDataStream.Length - 1; i++) {
                string dataset_0 = rxDataStream[i];
                string dataset_1 = rxDataStream[i + 1];
                //Console.WriteLine(dataset_0.Length);
                if ((dataset_0.Length == wordlength) && (dataset_1.Length == wordlength)) {
                    string timestamp0 = dataset_0.Substring(8, 8);
                    UInt32 timestamp_int0 = UInt32.Parse(timestamp0, NumberStyles.HexNumber);
                    string timestamp1 = dataset_1.Substring(8, 8);
                    UInt32 timestamp_int1 = UInt32.Parse(timestamp1, NumberStyles.HexNumber);
                    string portstatushex0 = dataset_0.Substring(0, 8);
                    if (!zeroTime) { //gets first timestamp and saves it as a zero
                        zero = timestamp_int0;
                        zeroTime = true;
                    }
                    //Console.WriteLine(dataset_0);
                    //Console.WriteLine(portstatushex0);
                    string portstatusbits = Convert.ToString(Int32.Parse(portstatushex0, NumberStyles.HexNumber), 2).PadLeft(n_sens, padpolarity);
                    for (int j = 0; j < portstatusbits.Length; j++) {
                        if ((lastBit[j] == '0' && portstatusbits[j] == '1') || (lastBit[j] == '1' && portstatusbits[j] == '0')) {
                            sensorDetected[j] = true;
                        }

                        if (portstatusbits[j] == '0' && sensorDetected[j]) {
                            if (first_timestampf[j]) {
                                last_timestampf[j] = timestamp_int0;
                                last_timestampff[j] = last_timestampf[j];
                                first_timestampf[j] = false;
                                first_timestampr[j] = true;
                                tempPoint = (last_timestampr[j] - zero) / sampFreq;
                                temp = timestamp_int0 - last_timestampr[j];

                                if (temp < 800000) {
                                    pdSeries[j].Points.AddXY(tempPoint, 1);
                                    if ((temp > 2750 && temp < 3250) ||
                                    (temp > 3750 && temp < 4250) ||
                                    (temp > 4750 && temp < 5250) ||
                                    (temp > 5750 && temp < 6250)) { //xrotor
                                        xRotor[j] = true;
                                    } else if ((temp > 3250 && temp < 3750) ||
                                    (temp > 4250 && temp < 4750) ||
                                    (temp > 5250 && temp < 5750) ||
                                    (temp > 6250 && temp < 6750)) { //yrotor
                                        xRotor[j] = false;
                                    }

                                    if (xRotor[j]) { //xrotor
                                        pdSeriesx[j].Points.AddXY(tempPoint, 1); //(double)((double)last_timestampr[j] - (double)zero) / 48000000.0
                                        if (j == 8)
                                            Console.WriteLine("x8_1 " + temp);
                                    } else {
                                        pdSeriesy[j].Points.AddXY(tempPoint, 1);
                                    }
                                    seriesCount[j]++;
                                }
                            }


                        } else if (portstatusbits[j] == '1' && sensorDetected[j]) {
                            if (first_timestampr[j]) {
                                last_timestampr[j] = timestamp_int0;
                                last_timestamprr[j] = last_timestampr[j];
                                first_timestampr[j] = false;
                                first_timestampf[j] = true;
                                tempPoint = (last_timestampf[j] - zero) / sampFreq;
                                temp = timestamp_int0 - last_timestampf[j];

                                if (temp < 800000) {
                                    pdSeries[j].Points.AddXY(tempPoint, 0);
                                    if (xRotor[j]) { //xrotor
                                        pdSeriesx[j].Points.AddXY(tempPoint, 0);
                                        if (j == 8)
                                            Console.WriteLine("x8_0 " + temp);
                                    } else {
                                        pdSeriesy[j].Points.AddXY(tempPoint, 0);
                                    }
                                    seriesCount[j]++;
                                }
                            }

                        }
                        //last_timestamp[j] = timestamp_int0;
                        lastBit[j] = portstatusbits[j];
                    }
                }

            }

            for (int i = 0; i < 32; i++) {

                if (sensorDetected[i]) {
                    //if (rotorCheckBox.Checked) {
                    //    chart1.Series.Add(pdSeriesx[i]);
                    //    chart1.Series.Add(pdSeriesy[i]);
                    //} else 
                    nSensorsDetected++;
                }
            }

            drawWaveforms();

            if (nSensorsDetected > 0) {
                sensDetLabel.Text = "Sensors Detected: " + nSensorsDetected;
                chart1.Series["No sensors detected"].Enabled = false;
            } else {
                sensDetLabel.Text = "Sensors Detected: " + nSensorsDetected;
            }
            //allRadioButton.Checked = true;
        }

        private void drawWaveforms() {
            //chart1.Series.Clear();
            if (nSensorsDetected > 0) {
                if (singleRadioButton.Checked && rotorCheckBox.Checked) {
                    bool senDet = false;
                    if (selectedSeries > 0) {
                        for (int i = 0; i < 32; i++) { //display the first sensor
                            if (i == selectedSeries) {
                                chart1.Series["PDx" + i].Enabled = true;
                                chart1.Series["PDy" + i].Enabled = true;
                                chart1.Series["PD" + i].Enabled = false;
                                senDet = true;
                            } else {
                                chart1.Series["PDx" + i].Enabled = false;
                                chart1.Series["PDy" + i].Enabled = false;
                                chart1.Series["PD" + i].Enabled = false;
                            }
                        }
                    } else {
                        for (int i = 0; i < 32; i++) { //display the first sensor
                            if (sensorDetected[i] && !senDet) {
                                //chart1.Series[i].Color = pdColor[i];
                                //chart1.Series.Add(pdSeriesx[i]);
                                //chart1.Series.Add(pdSeriesy[i]);
                                chart1.Series["PDx" + i].Enabled = true;
                                chart1.Series["PDy" + i].Enabled = true;
                                chart1.Series["PD" + i].Enabled = false;
                                senDet = true;
                            } else {
                                chart1.Series["PDx" + i].Enabled = false;
                                chart1.Series["PDy" + i].Enabled = false;
                                chart1.Series["PD" + i].Enabled = false;
                            }
                        }
                    }
                    Console.WriteLine("drawWaveforms1");
                } else if (singleRadioButton.Checked) {
                    bool senDet = false;
                    if (selectedSeries > 0) {
                        for (int i = 0; i < 32; i++) { //display the first sensor
                            if (i == selectedSeries) {
                                chart1.Series["PD" + i].Enabled = true;
                                chart1.Series["PDx" + i].Enabled = false;
                                chart1.Series["PDy" + i].Enabled = false;
                                senDet = true;
                            } else {
                                chart1.Series["PDx" + i].Enabled = false;
                                chart1.Series["PDy" + i].Enabled = false;
                                chart1.Series["PD" + i].Enabled = false;
                            }
                        }
                    } else {
                        for (int i = 0; i < 32; i++) { //display the first sensor
                            if (sensorDetected[i] && !senDet) {
                                //chart1.Series.Add(pdSeries[i]);
                                chart1.Series["PD" + i].Enabled = true;
                                chart1.Series["PDx" + i].Enabled = false;
                                chart1.Series["PDy" + i].Enabled = false;
                                senDet = true;
                            } else {
                                chart1.Series["PDx" + i].Enabled = false;
                                chart1.Series["PDy" + i].Enabled = false;
                                chart1.Series["PD" + i].Enabled = false;
                            }
                        }
                    }
                    Console.WriteLine("drawWaveforms2");
                } else if (allRadioButton.Checked && rotorCheckBox.Checked) {
                    //chart1.Series.Clear();
                    for (int i = 0; i < 32; i++) {
                        if (sensorDetected[i]) {
                            //chart1.Series.Add(pdSeriesx[i]);
                            //chart1.Series.Add(pdSeriesy[i]);
                            //chart1.Series["PDx" + i].Color = pdColor[i];
                            chart1.Series["PDx" + i].Enabled = true;
                            chart1.Series["PDy" + i].Enabled = true;
                            chart1.Series["PD" + i].Enabled = false;
                        } else {
                            chart1.Series["PDx" + i].Enabled = false;
                            chart1.Series["PDy" + i].Enabled = false;
                            chart1.Series["PD" + i].Enabled = false;
                        }
                    }
                    Console.WriteLine("drawWaveforms3");
                } else if (allRadioButton.Checked) {
                    //chart1.Series.Clear();
                    for (int i = 0; i < 32; i++) {
                        if (sensorDetected[i]) {
                            chart1.Series["PD" + i].Enabled = true;
                            chart1.Series["PDx" + i].Enabled = false;
                            chart1.Series["PDy" + i].Enabled = false;
                        } else {
                            chart1.Series["PDx" + i].Enabled = false;
                            chart1.Series["PDy" + i].Enabled = false;
                            chart1.Series["PD" + i].Enabled = false;
                        }
                    }
                    Console.WriteLine("drawWaveforms4");
                }

            } else {
                for (int i = 0; i < 32; i++) { //display the first sensor
                    chart1.Series["PDx" + i].Enabled = false;
                    chart1.Series["PDy" + i].Enabled = false;
                    chart1.Series["PD" + i].Enabled = false;
                }
                chart1.Series["No sensors detected"].Enabled = true;
                Console.WriteLine("drawWaveforms5");
            }

        }

        private void sampleTextBox_KeyPressed(object sender, KeyPressEventArgs e) {

            if (!char.IsControl(e.KeyChar)  // only allow digits
                && !char.IsDigit(e.KeyChar)
                && (e.KeyChar != '.')) {
                e.Handled = true;
            }
            if ((e.KeyChar == '.')          // only allow one decimal point                 
                && ((sender as TextBox).Text.IndexOf('.') > -1)) {
                e.Handled = true;
            }
        }

        private void sampleTextBox_TextChanged(object sender, EventArgs e) {
            var textbox = sender as TextBox;
            double value;
            if (double.TryParse(textbox.Text, out value)) {
                if (value > 20.0)
                    textbox.Text = "22.0";
                else if (value < 0)
                    textbox.Text = "0.8";
            }
        }

        private void clearButton_Click(object sender, EventArgs e) {
            for (int i = 0; i < pdSeries.Length; i++) {
                //if (sensorDetected[i]) {
                chart1.Series["PD" + i].Points.Clear();
                chart1.Series["PDx" + i].Points.Clear();
                chart1.Series["PDy" + i].Points.Clear();
                //}
                //pdSeries[i].Points.Clear();
                //chart1.Series.RemoveAt(0);
            }
            selectedSeries = -1;

            while (chart1.ChartAreas[0].AxisX.ScaleView.IsZoomed)
                chart1.ChartAreas["ChartArea1"].AxisX.ScaleView.ZoomReset();
            rxData.Clear();

            Array.Clear(anglePrevCount, 0, anglePrevCount.Length);
            Array.Clear(anglePrevMean, 0, anglePrevMean.Length);
            Array.Clear(anglePrevSum, 0, anglePrevSum.Length);
            Array.Clear(anglePrevSumSq, 0, anglePrevSumSq.Length);
            Array.Clear(anglePrevVar, 0, anglePrevVar.Length);
            Array.Clear(anglePrevStdDev, 0, anglePrevStdDev.Length);

            Array.Clear(angleCount, 0, angleCount.Length);
            Array.Clear(angleMean, 0, angleMean.Length);
            Array.Clear(angleSum, 0, angleSum.Length);
            Array.Clear(angleSumSq, 0, angleSumSq.Length);
            Array.Clear(angleVar, 0, angleVar.Length);
            Array.Clear(angleStdDev, 0, angleStdDev.Length);

            invalid_long = 0;
            runt = 0;
            sync_miss = 0;
            samples_in_guard_band = 0;
        }

        private void aboutToolStripMenuItem_Click(object sender, EventArgs e) {
            TextDialog.ShowDialog("\u00a9 2017 NoiseFigure Research\n"
                                        + "All Rights Reserved", "About");
        }

        private void userInfoToolStripMenuItem_Click(object sender, EventArgs e) {
            TextDialog.ShowDialog("1. Connect usb cable to i40 Board (drivers will install on first plug in) \n"
                                    + "2. Find USB to serial COM port number using Windows Device Manager.\n"
                                    + "3. Click the COM Port drop down menu and select the port from the list.\n"
                                    + "4. Set the record time desired (default 1 sec)\n"
                                    + "5. Click \"Record\" and the sensor waveform(s) will be displayed in a graph.\n\n", "User Guide");
        }

        private void themeClick(object sender, EventArgs e) {
            string mItem = ((ToolStripMenuItem)sender).Text;

            switch (mItem) {
                case "Dusk":
                    duskToolStripMenuItem.Checked = true;
                    formalToolStripMenuItem.Checked = false;
                    this.BackColor = System.Drawing.SystemColors.ControlDark;
                    chart1.BackColor = System.Drawing.SystemColors.ControlDark;
                    break;
                case "Formal":
                    duskToolStripMenuItem.Checked = false;
                    formalToolStripMenuItem.Checked = true;
                    this.BackColor = System.Drawing.SystemColors.Control;
                    chart1.BackColor = System.Drawing.SystemColors.Control;
                    break;

            }
            //Console.WriteLine("click");
            //Console.WriteLine("duskToolStripMenuItem " + duskToolStripMenuItem.Checked.ToString());
            //Console.WriteLine("formalToolStripMenuItem " + formalToolStripMenuItem.Checked.ToString());

        }

        private void syncRefClick(object sender, EventArgs e) {
            string mItem = ((ToolStripMenuItem)sender).Text;

            switch (mItem) {
                case "First Edge":
                    firstEdgeToolStripMenuItem.Checked = true;
                    averageToolStripMenuItem.Checked = false;
                    minMaxAvgToolStripMenuItem.Checked = false;
                    clearButton_Click(null, null);
                    break;
                case "Average":
                    firstEdgeToolStripMenuItem.Checked = false;
                    averageToolStripMenuItem.Checked = true;
                    minMaxAvgToolStripMenuItem.Checked = false;
                    clearButton_Click(null, null);
                    break;
                case "Min Max Avg":
                    firstEdgeToolStripMenuItem.Checked = false;
                    averageToolStripMenuItem.Checked = false;
                    minMaxAvgToolStripMenuItem.Checked = true;
                    clearButton_Click(null, null);
                    break;

            }
        }

        private void chart1_MouseClick(object sender, MouseEventArgs e) {
            //string parameterNameStr;
            System.Windows.Forms.DataVisualization.Charting.HitTestResult seriesHit = chart1.HitTest(e.X, e.Y);
            if (seriesHit.ChartElementType == System.Windows.Forms.DataVisualization.Charting.ChartElementType.DataPoint) { //click on waveform
                //parameterNameStr = seriesHit.Series.Name;
                Console.WriteLine("Selected by Series!" + seriesHit.Series.Name);
                for (int i = 0; i < chart1.Series.Count; i++) {
                    if (chart1.Series[i].Name == seriesHit.Series.Name) {
                        selectedSeries = Int32.Parse(System.Text.RegularExpressions.Regex.Match(seriesHit.Series.Name, @"\d+").Value);
                        chart1.Series[i].BorderWidth = 4;
                        chart1.Series[i].LegendText = ">" + seriesHit.Series.Name;
                    } else {
                        chart1.Series[i].BorderWidth = 1;
                        chart1.Series[i].LegendText = chart1.Series[i].Name;
                    }

                }
            } else if (seriesHit.ChartElementType == System.Windows.Forms.DataVisualization.Charting.ChartElementType.LegendItem) { //click on legend
                Console.WriteLine("Selected by Legend!!" + seriesHit.Series.Name);
                for (int i = 0; i < chart1.Series.Count; i++) {
                    if (chart1.Series[i].Name == seriesHit.Series.Name) {
                        chart1.Series[i].BorderWidth = 4;
                        chart1.Series[i].LegendText = ">" + seriesHit.Series.Name;
                        selectedSeries = Int32.Parse(System.Text.RegularExpressions.Regex.Match(seriesHit.Series.Name, @"\d+").Value);
                    } else {
                        chart1.Series[i].BorderWidth = 1;
                        chart1.Series[i].LegendText = chart1.Series[i].Name;
                    }
                }
            } else {
                Console.WriteLine("Whoops, try again!");
                for (int i = 0; i < chart1.Series.Count; i++) {
                    chart1.Series[i].BorderWidth = 1;
                    chart1.Series[i].LegendText = chart1.Series[i].Name;
                }
                //selectedSeries = -1; 
            }
        }

        //private void seriesHitUpdateSingle(Series ser) {

        //        }

        private void exportToolStripMenuItem_Click(object sender, EventArgs e) {
            SaveFileDialog save = new SaveFileDialog();

            save.FileName = "DefaultOutputName.txt";
            save.Filter = "Text file (*.txt)|*.txt|CSV file(*.csv)|*.csv";

            if (save.ShowDialog() == DialogResult.OK) {

                System.IO.StreamWriter writer = new System.IO.StreamWriter(save.OpenFile());


                writer.WriteLine("0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,timestamp");
                rxDataStream = rxData.ToString().Split(new string[] { "\n" }, StringSplitOptions.None);
                for (int i = 0; i < rxDataStream.Length - 1; i++) {
                    //Console.WriteLine(rxDataStream[i].Length);
                    string portstatusbits = Convert.ToString(Int32.Parse(rxDataStream[i].Substring(0, 8), NumberStyles.HexNumber), 2).PadLeft(n_sens, padpolarity);
                    for (int j = 0; j < 32; j++) {
                        writer.Write(portstatusbits[j]);
                        writer.Write(',');
                    }
                    //writer.Write(rxDataStream[i].Substring(8,8));// hex
                    writer.WriteLine(UInt32.Parse(rxDataStream[i].Substring(8, 8), NumberStyles.HexNumber)); //int
                }

                writer.Dispose();
                writer.Close();

            }

        }

        private void chart1_MouseWheel(object sender, MouseEventArgs e) {
            try {
                if (e.Delta <= 0) {
                    //chart1.ChartAreas[0].AxisX.ScaleView.ZoomReset();
                    double xMin = chart1.ChartAreas[0].AxisX.ScaleView.ViewMinimum;
                    double xMax = chart1.ChartAreas[0].AxisX.ScaleView.ViewMaximum;

                    double posXStart = chart1.ChartAreas[0].AxisX.PixelPositionToValue(e.Location.X) - (xMax - xMin);
                    double posXFinish = chart1.ChartAreas[0].AxisX.PixelPositionToValue(e.Location.X) + (xMax - xMin);

                    //Console.WriteLine("xMin" + xMin);
                    //Console.WriteLine("xMax" + xMax);
                    //Console.WriteLine("posXStart" + posXStart);
                    //Console.WriteLine("posXFinish" + posXFinish);
                    //Console.WriteLine("textbox" + Convert.ToDouble(sampleTextBox.Text));
                    if (posXFinish > Convert.ToDouble(sampleTextBox.Text) || posXStart < 0) {
                        while (chart1.ChartAreas[0].AxisX.ScaleView.IsZoomed)
                            chart1.ChartAreas["ChartArea1"].AxisX.ScaleView.ZoomReset();
                    } else {
                        chart1.ChartAreas[0].AxisX.ScaleView.Zoom(posXStart, posXFinish);
                    }

                } else if (e.Delta > 0) {
                    double xMin = chart1.ChartAreas[0].AxisX.ScaleView.ViewMinimum;
                    double xMax = chart1.ChartAreas[0].AxisX.ScaleView.ViewMaximum;

                    double posXStart = chart1.ChartAreas[0].AxisX.PixelPositionToValue(e.Location.X) - (xMax - xMin) / 4;
                    double posXFinish = chart1.ChartAreas[0].AxisX.PixelPositionToValue(e.Location.X) + (xMax - xMin) / 4;

                    chart1.ChartAreas[0].AxisX.ScaleView.Zoom(posXStart, posXFinish);
                }
            } catch { }
        }

        private void radioButtonOrCheckBoxClick(object sender, MouseEventArgs e) {
            drawWaveforms();
        }
    }
}
