﻿using System.Linq;

namespace WaveformViewer {
    partial class Form1 {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing) {
            if (disposing && (components != null)) {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent() {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea1 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend1 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series1 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.comGroupBox = new System.Windows.Forms.GroupBox();
            this.rotorCheckBox = new System.Windows.Forms.CheckBox();
            this.singleRadioButton = new System.Windows.Forms.RadioButton();
            this.allRadioButton = new System.Windows.Forms.RadioButton();
            this.label3 = new System.Windows.Forms.Label();
            this.sensDetLabel = new System.Windows.Forms.Label();
            this.runningLabel = new System.Windows.Forms.Label();
            this.clearConsoleButton = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.sampleTextBox = new System.Windows.Forms.TextBox();
            this.comComboBox = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.testButton = new System.Windows.Forms.Button();
            this.recTimeLabel = new System.Windows.Forms.Label();
            this.graphGroupBox = new System.Windows.Forms.GroupBox();
            this.chart1 = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.serialPort1 = new System.IO.Ports.SerialPort(this.components);
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exportToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.editToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.themeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.duskToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.formalToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.syncToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.firstEdgeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.averageToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.minMaxAvgToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.helpToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.userInfoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aboutToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.comGroupBox.SuspendLayout();
            this.graphGroupBox.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.chart1)).BeginInit();
            this.tableLayoutPanel1.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // comGroupBox
            // 
            this.comGroupBox.Controls.Add(this.rotorCheckBox);
            this.comGroupBox.Controls.Add(this.singleRadioButton);
            this.comGroupBox.Controls.Add(this.allRadioButton);
            this.comGroupBox.Controls.Add(this.label3);
            this.comGroupBox.Controls.Add(this.sensDetLabel);
            this.comGroupBox.Controls.Add(this.runningLabel);
            this.comGroupBox.Controls.Add(this.clearConsoleButton);
            this.comGroupBox.Controls.Add(this.label2);
            this.comGroupBox.Controls.Add(this.sampleTextBox);
            this.comGroupBox.Controls.Add(this.comComboBox);
            this.comGroupBox.Controls.Add(this.label1);
            this.comGroupBox.Controls.Add(this.testButton);
            this.comGroupBox.Controls.Add(this.recTimeLabel);
            this.comGroupBox.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comGroupBox.Location = new System.Drawing.Point(128, 2);
            this.comGroupBox.Name = "comGroupBox";
            this.comGroupBox.Size = new System.Drawing.Size(510, 130);
            this.comGroupBox.TabIndex = 0;
            this.comGroupBox.TabStop = false;
            this.comGroupBox.Text = "Communication";
            // 
            // rotorCheckBox
            // 
            this.rotorCheckBox.AutoSize = true;
            this.rotorCheckBox.Location = new System.Drawing.Point(297, 100);
            this.rotorCheckBox.Name = "rotorCheckBox";
            this.rotorCheckBox.Size = new System.Drawing.Size(95, 20);
            this.rotorCheckBox.TabIndex = 25;
            this.rotorCheckBox.Text = "Split Rotors";
            this.rotorCheckBox.UseVisualStyleBackColor = true;
            this.rotorCheckBox.MouseClick += new System.Windows.Forms.MouseEventHandler(this.radioButtonOrCheckBoxClick);
            // 
            // singleRadioButton
            // 
            this.singleRadioButton.AutoSize = true;
            this.singleRadioButton.Location = new System.Drawing.Point(186, 102);
            this.singleRadioButton.Name = "singleRadioButton";
            this.singleRadioButton.Size = new System.Drawing.Size(62, 20);
            this.singleRadioButton.TabIndex = 23;
            this.singleRadioButton.Text = "Single";
            this.singleRadioButton.UseVisualStyleBackColor = true;
            this.singleRadioButton.MouseClick += new System.Windows.Forms.MouseEventHandler(this.radioButtonOrCheckBoxClick);
            // 
            // allRadioButton
            // 
            this.allRadioButton.AutoSize = true;
            this.allRadioButton.Checked = true;
            this.allRadioButton.Location = new System.Drawing.Point(123, 102);
            this.allRadioButton.Name = "allRadioButton";
            this.allRadioButton.Size = new System.Drawing.Size(41, 20);
            this.allRadioButton.TabIndex = 22;
            this.allRadioButton.TabStop = true;
            this.allRadioButton.Text = "All";
            this.allRadioButton.UseVisualStyleBackColor = true;
            this.allRadioButton.MouseClick += new System.Windows.Forms.MouseEventHandler(this.radioButtonOrCheckBoxClick);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(6, 104);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(105, 16);
            this.label3.TabIndex = 21;
            this.label3.Text = "Waveform Mode:";
            // 
            // sensDetLabel
            // 
            this.sensDetLabel.AutoSize = true;
            this.sensDetLabel.Location = new System.Drawing.Point(6, 80);
            this.sensDetLabel.Name = "sensDetLabel";
            this.sensDetLabel.Size = new System.Drawing.Size(127, 16);
            this.sensDetLabel.TabIndex = 20;
            this.sensDetLabel.Text = "Sensors Detected: 0";
            // 
            // runningLabel
            // 
            this.runningLabel.AutoSize = true;
            this.runningLabel.Location = new System.Drawing.Point(425, 85);
            this.runningLabel.Name = "runningLabel";
            this.runningLabel.Size = new System.Drawing.Size(67, 16);
            this.runningLabel.TabIndex = 19;
            this.runningLabel.Text = "Running...";
            this.runningLabel.Visible = false;
            // 
            // clearConsoleButton
            // 
            this.clearConsoleButton.Location = new System.Drawing.Point(297, 54);
            this.clearConsoleButton.Name = "clearConsoleButton";
            this.clearConsoleButton.Size = new System.Drawing.Size(98, 28);
            this.clearConsoleButton.TabIndex = 18;
            this.clearConsoleButton.Text = "Clear";
            this.clearConsoleButton.UseVisualStyleBackColor = true;
            this.clearConsoleButton.Click += new System.EventHandler(this.clearButton_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(183, 54);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(92, 16);
            this.label2.TabIndex = 17;
            this.label2.Text = "range (.5-22.0)";
            // 
            // sampleTextBox
            // 
            this.sampleTextBox.Location = new System.Drawing.Point(123, 51);
            this.sampleTextBox.Name = "sampleTextBox";
            this.sampleTextBox.Size = new System.Drawing.Size(57, 22);
            this.sampleTextBox.TabIndex = 15;
            this.sampleTextBox.Text = "1.0";
            this.sampleTextBox.TextChanged += new System.EventHandler(this.sampleTextBox_TextChanged);
            this.sampleTextBox.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.sampleTextBox_KeyPressed);
            // 
            // comComboBox
            // 
            this.comComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comComboBox.FormattingEnabled = true;
            this.comComboBox.Location = new System.Drawing.Point(89, 23);
            this.comComboBox.Name = "comComboBox";
            this.comComboBox.Size = new System.Drawing.Size(410, 24);
            this.comComboBox.TabIndex = 3;
            this.comComboBox.SelectedIndexChanged += new System.EventHandler(this.comComboBox_SelectedIndexChanged);
            this.comComboBox.MouseClick += new System.Windows.Forms.MouseEventHandler(this.comComboBox_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(6, 26);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(70, 16);
            this.label1.TabIndex = 0;
            this.label1.Text = "COM Port:";
            // 
            // testButton
            // 
            this.testButton.Location = new System.Drawing.Point(401, 54);
            this.testButton.Name = "testButton";
            this.testButton.Size = new System.Drawing.Size(98, 28);
            this.testButton.TabIndex = 7;
            this.testButton.Text = "Record";
            this.testButton.UseVisualStyleBackColor = true;
            this.testButton.Click += new System.EventHandler(this.testButton_Click);
            // 
            // recTimeLabel
            // 
            this.recTimeLabel.AutoSize = true;
            this.recTimeLabel.Location = new System.Drawing.Point(6, 54);
            this.recTimeLabel.Name = "recTimeLabel";
            this.recTimeLabel.Size = new System.Drawing.Size(121, 16);
            this.recTimeLabel.TabIndex = 14;
            this.recTimeLabel.Text = "Recording Time (s):";
            // 
            // graphGroupBox
            // 
            this.graphGroupBox.AutoSize = true;
            this.graphGroupBox.Controls.Add(this.chart1);
            this.graphGroupBox.Dock = System.Windows.Forms.DockStyle.Fill;
            this.graphGroupBox.Location = new System.Drawing.Point(3, 168);
            this.graphGroupBox.Name = "graphGroupBox";
            this.graphGroupBox.Size = new System.Drawing.Size(659, 397);
            this.graphGroupBox.TabIndex = 1;
            this.graphGroupBox.TabStop = false;
            this.graphGroupBox.Text = "Graph";
            // 
            // chart1
            // 
            chartArea1.BorderColor = System.Drawing.Color.LightGray;
            chartArea1.Name = "ChartArea1";
            this.chart1.ChartAreas.Add(chartArea1);
            this.chart1.Dock = System.Windows.Forms.DockStyle.Fill;
            legend1.Name = "Legend1";
            this.chart1.Legends.Add(legend1);
            this.chart1.Location = new System.Drawing.Point(3, 16);
            this.chart1.Name = "chart1";
            this.chart1.Palette = System.Windows.Forms.DataVisualization.Charting.ChartColorPalette.Pastel;
            series1.ChartArea = "ChartArea1";
            series1.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.StepLine;
            series1.LabelForeColor = System.Drawing.Color.Gainsboro;
            series1.Legend = "Legend1";
            series1.Name = "Series1";
            series1.XValueType = System.Windows.Forms.DataVisualization.Charting.ChartValueType.UInt32;
            this.chart1.Series.Add(series1);
            this.chart1.Size = new System.Drawing.Size(653, 378);
            this.chart1.TabIndex = 0;
            this.chart1.Text = "chart1";
            this.chart1.MouseClick += new System.Windows.Forms.MouseEventHandler(this.chart1_MouseClick);
            this.chart1.MouseWheel += new System.Windows.Forms.MouseEventHandler(this.chart1_MouseWheel);
            // 
            // serialPort1
            // 
            this.serialPort1.DataReceived += new System.IO.Ports.SerialDataReceivedEventHandler(this.DataReceivedHandler);
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 1;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 665F));
            this.tableLayoutPanel1.Controls.Add(this.groupBox1, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.graphGroupBox, 0, 1);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 24);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 165F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(665, 568);
            this.tableLayoutPanel1.TabIndex = 2;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.panel1);
            this.groupBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox1.Location = new System.Drawing.Point(3, 3);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(659, 159);
            this.groupBox1.TabIndex = 21;
            this.groupBox1.TabStop = false;
            // 
            // panel1
            // 
            this.panel1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.panel1.Controls.Add(this.comGroupBox);
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Location = new System.Drawing.Point(8, 6);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(642, 135);
            this.panel1.TabIndex = 21;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pictureBox1.Image = global::WaveformViewer.Properties.Resources.VirtualBuildsHD2;
            this.pictureBox1.InitialImage = ((System.Drawing.Image)(resources.GetObject("pictureBox1.InitialImage")));
            this.pictureBox1.Location = new System.Drawing.Point(3, 25);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(119, 78);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 20;
            this.pictureBox1.TabStop = false;
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem,
            this.editToolStripMenuItem,
            this.helpToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(665, 24);
            this.menuStrip1.TabIndex = 3;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.exportToolStripMenuItem,
            this.exitToolStripMenuItem});
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(37, 20);
            this.fileToolStripMenuItem.Text = "File";
            // 
            // exportToolStripMenuItem
            // 
            this.exportToolStripMenuItem.Name = "exportToolStripMenuItem";
            this.exportToolStripMenuItem.Size = new System.Drawing.Size(142, 22);
            this.exportToolStripMenuItem.Text = "Export Graph";
            this.exportToolStripMenuItem.Click += new System.EventHandler(this.exportToolStripMenuItem_Click);
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(142, 22);
            this.exitToolStripMenuItem.Text = "Exit";
            this.exitToolStripMenuItem.Click += new System.EventHandler(this.exitToolStripMenuItem_Click);
            // 
            // editToolStripMenuItem
            // 
            this.editToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.themeToolStripMenuItem,
            this.syncToolStripMenuItem});
            this.editToolStripMenuItem.Name = "editToolStripMenuItem";
            this.editToolStripMenuItem.Size = new System.Drawing.Size(39, 20);
            this.editToolStripMenuItem.Text = "Edit";
            // 
            // themeToolStripMenuItem
            // 
            this.themeToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.duskToolStripMenuItem,
            this.formalToolStripMenuItem});
            this.themeToolStripMenuItem.Name = "themeToolStripMenuItem";
            this.themeToolStripMenuItem.Size = new System.Drawing.Size(119, 22);
            this.themeToolStripMenuItem.Text = "Theme";
            // 
            // duskToolStripMenuItem
            // 
            this.duskToolStripMenuItem.CheckOnClick = true;
            this.duskToolStripMenuItem.Name = "duskToolStripMenuItem";
            this.duskToolStripMenuItem.Size = new System.Drawing.Size(111, 22);
            this.duskToolStripMenuItem.Text = "Dusk";
            this.duskToolStripMenuItem.Click += new System.EventHandler(this.themeClick);
            // 
            // formalToolStripMenuItem
            // 
            this.formalToolStripMenuItem.Checked = true;
            this.formalToolStripMenuItem.CheckOnClick = true;
            this.formalToolStripMenuItem.CheckState = System.Windows.Forms.CheckState.Checked;
            this.formalToolStripMenuItem.Name = "formalToolStripMenuItem";
            this.formalToolStripMenuItem.Size = new System.Drawing.Size(111, 22);
            this.formalToolStripMenuItem.Text = "Formal";
            this.formalToolStripMenuItem.Click += new System.EventHandler(this.themeClick);
            // 
            // syncToolStripMenuItem
            // 
            this.syncToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.firstEdgeToolStripMenuItem,
            this.averageToolStripMenuItem,
            this.minMaxAvgToolStripMenuItem});
            this.syncToolStripMenuItem.Name = "syncToolStripMenuItem";
            this.syncToolStripMenuItem.Size = new System.Drawing.Size(119, 22);
            this.syncToolStripMenuItem.Text = "Sync Ref";
            // 
            // firstEdgeToolStripMenuItem
            // 
            this.firstEdgeToolStripMenuItem.Checked = true;
            this.firstEdgeToolStripMenuItem.CheckState = System.Windows.Forms.CheckState.Checked;
            this.firstEdgeToolStripMenuItem.Name = "firstEdgeToolStripMenuItem";
            this.firstEdgeToolStripMenuItem.Size = new System.Drawing.Size(144, 22);
            this.firstEdgeToolStripMenuItem.Text = "First Edge";
            this.firstEdgeToolStripMenuItem.Click += new System.EventHandler(this.syncRefClick);
            // 
            // averageToolStripMenuItem
            // 
            this.averageToolStripMenuItem.Name = "averageToolStripMenuItem";
            this.averageToolStripMenuItem.Size = new System.Drawing.Size(144, 22);
            this.averageToolStripMenuItem.Text = "Average";
            this.averageToolStripMenuItem.Click += new System.EventHandler(this.syncRefClick);
            // 
            // minMaxAvgToolStripMenuItem
            // 
            this.minMaxAvgToolStripMenuItem.Name = "minMaxAvgToolStripMenuItem";
            this.minMaxAvgToolStripMenuItem.Size = new System.Drawing.Size(144, 22);
            this.minMaxAvgToolStripMenuItem.Text = "Min Max Avg";
            this.minMaxAvgToolStripMenuItem.Click += new System.EventHandler(this.syncRefClick);
            // 
            // helpToolStripMenuItem
            // 
            this.helpToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.userInfoToolStripMenuItem,
            this.aboutToolStripMenuItem});
            this.helpToolStripMenuItem.Name = "helpToolStripMenuItem";
            this.helpToolStripMenuItem.Size = new System.Drawing.Size(44, 20);
            this.helpToolStripMenuItem.Text = "Help";
            // 
            // userInfoToolStripMenuItem
            // 
            this.userInfoToolStripMenuItem.Name = "userInfoToolStripMenuItem";
            this.userInfoToolStripMenuItem.Size = new System.Drawing.Size(131, 22);
            this.userInfoToolStripMenuItem.Text = "User Guide";
            this.userInfoToolStripMenuItem.Click += new System.EventHandler(this.userInfoToolStripMenuItem_Click);
            // 
            // aboutToolStripMenuItem
            // 
            this.aboutToolStripMenuItem.Name = "aboutToolStripMenuItem";
            this.aboutToolStripMenuItem.Size = new System.Drawing.Size(131, 22);
            this.aboutToolStripMenuItem.Text = "About";
            this.aboutToolStripMenuItem.Click += new System.EventHandler(this.aboutToolStripMenuItem_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Control;
            this.ClientSize = new System.Drawing.Size(665, 592);
            this.Controls.Add(this.tableLayoutPanel1);
            this.Controls.Add(this.menuStrip1);
            this.ForeColor = System.Drawing.SystemColors.ControlText;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form1";
            this.Text = "Virtual Builds Waveform Viewer";
            this.comGroupBox.ResumeLayout(false);
            this.comGroupBox.PerformLayout();
            this.graphGroupBox.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.chart1)).EndInit();
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        private System.Collections.Generic.Dictionary<string, string> BuildPortNameHash(string[] portsToMap) {
            System.Collections.Generic.Dictionary<string, string> oReturnTable = new System.Collections.Generic.Dictionary<string, string>();
            MineRegistryForPortName("SYSTEM\\CurrentControlSet\\Enum", oReturnTable, portsToMap);
            return oReturnTable;
        }

        private void MineRegistryForPortName(string startKeyPath, System.Collections.Generic.Dictionary<string, string> targetMap,
                                                string[] portsToMap) {
            if (targetMap.Count >= portsToMap.Length)
                return;
            using (Microsoft.Win32.RegistryKey currentKey = Microsoft.Win32.Registry.LocalMachine) {
                try {
                    using (Microsoft.Win32.RegistryKey currentSubKey = currentKey.OpenSubKey(startKeyPath)) {
                        string[] currentSubkeys = currentSubKey.GetSubKeyNames();
                        if (currentSubkeys.Contains("Device Parameters") &&
                            startKeyPath != "SYSTEM\\CurrentControlSet\\Enum") {
                            object portName = Microsoft.Win32.Registry.GetValue("HKEY_LOCAL_MACHINE\\" +
                                startKeyPath + "\\Device Parameters", "PortName", null);
                            if (portName == null ||
                                portsToMap.Contains(portName.ToString()) == false)
                                return;
                            object friendlyPortName = Microsoft.Win32.Registry.GetValue("HKEY_LOCAL_MACHINE\\" +
                                startKeyPath, "FriendlyName", null);
                            string friendlyName = "N/A";
                            if (friendlyPortName != null)
                                friendlyName = friendlyPortName.ToString();
                            if (friendlyName.Contains(portName.ToString()) == false)
                                friendlyName = string.Format("{0} ({1})", friendlyName, portName);
                            targetMap[portName.ToString()] = friendlyName;
                        } else {
                            foreach (string strSubKey in currentSubkeys)
                                MineRegistryForPortName(startKeyPath + "\\" + strSubKey, targetMap, portsToMap);
                        }
                    }
                } catch (System.Exception) {
                    //System.Console.WriteLine("Error accessing key '{0}'.. Skipping..", startKeyPath);
                }
            }
        }

        #endregion

        private static int baud_rate = 2000000;//460800 2000000
        private static int n_sens = 32;
        private static int n_axis = 4;

        private int sync_long = 12000;
        private char pinpolarity = '1';
        private char negpinpolarity = '0';
        private char padpolarity = '0';
        private string portpolarity = "00000000";

        private uint[] r_timestamps;// = new uint[sensors];
        private bool[] r_time;// = new bool[sensors];
        private uint[] f_timestamps;// = new uint[sensors];
        private uint[] c_timestamps;// = new uint[sensors];

        private string[] rxDataStream;
        private bool[] ubase;//state
        private int TDM;
        private int syncLaser;
        private bool modeBC;

        private int invalid_long;
        private int runt;
        private int sync_miss;
        private int samples_in_guard_band;

        private int[] sync_sensor = new int[n_axis];
        private int[] sample_sensor = new int[n_axis];
        private int[] multihit_sensors = new int[n_axis];
        private int[] width_delta = new int[n_axis];

        private string u0id = "\"Base 1\"";
        private string u1id = "\"Base 2\"";
        private System.Collections.Generic.List<double> u0xperiodArray = new System.Collections.Generic.List<double>();
        private System.Collections.Generic.List<double> u0yperiodArray = new System.Collections.Generic.List<double>();
        private System.Collections.Generic.List<double> u1xperiodArray = new System.Collections.Generic.List<double>();
        private System.Collections.Generic.List<double> u1yperiodArray = new System.Collections.Generic.List<double>();

        private int u0xperiodCount;
        private double u0xperiodMean;
        private double u0xperiodSum;
        private double u0xperiodSumSq;
        private double u0xperiodVar;
        private double u0xperiodStdDev;
        private int u0xperiodPrevCount;
        private double u0xperiodPrevMean;
        private double u0xperiodPrevSum;
        private double u0xperiodPrevSumSq;
        private double u0xperiodPrevVar;
        private double u0xperiodPrevStdDev;

        private int u0yperiodCount;
        private double u0yperiodMean;
        private double u0yperiodSum;
        private double u0yperiodSumSq;
        private double u0yperiodVar;
        private double u0yperiodStdDev;
        private int u0yperiodPrevCount;
        private double u0yperiodPrevMean;
        private double u0yperiodPrevSum;
        private double u0yperiodPrevSumSq;
        private double u0yperiodPrevVar;
        private double u0yperiodPrevStdDev;

        private int u1xperiodCount;
        private double u1xperiodMean;
        private double u1xperiodSum;
        private double u1xperiodSumSq;
        private double u1xperiodVar;
        private double u1xperiodStdDev;
        private int u1xperiodPrevCount;
        private double u1xperiodPrevMean;
        private double u1xperiodPrevSum;
        private double u1xperiodPrevSumSq;
        private double u1xperiodPrevVar;
        private double u1xperiodPrevStdDev;

        private int u1yperiodCount;
        private double u1yperiodMean;
        private double u1yperiodSum;
        private double u1yperiodSumSq;
        private double u1yperiodVar;
        private double u1yperiodStdDev;
        private int u1yperiodPrevCount;
        private double u1yperiodPrevMean;
        private double u1yperiodPrevSum;
        private double u1yperiodPrevSumSq;
        private double u1yperiodPrevVar;
        private double u1yperiodPrevStdDev;

        //u0
        private bool[] u0axis;// = new bool[16];
        private bool[] u0skip;// = new bool[16];
        private int[] u0xpos_i;// = new int[32];//
        private int[] u0ypos_i;// = new int[16];//
        private int[] u0xsync_i;// = new int[16];// 
        private int[] u0ysync_i;// = new int[16];// 
        private uint[,] u0xpos;// = new uint[16, 16 * 4 * 1200]; //channels*timestamps per period*periods in max time
        private uint[,] u0ypos;// = new uint[16, 16 * 4 * 1200];
        private uint[,] u0xsync_timestamps;// = new uint[16, 16 * 4 * 1200];
        private uint[,] u0ysync_timestamps;// = new uint[16, 16 * 4 * 1200];
        private uint[,] u0xgsync_timestamps;// = new uint[16, 16 * 4 * 1200];
        private uint[,] u0ygsync_timestamps;// = new uint[16, 16 * 4 * 1200];

        //u1
        private bool[] u1axis;// = new bool[16];
        private bool[] u1skip;// = new bool[16];
        private int[] u1xpos_i;// = new int[32];//
        private int[] u1ypos_i;// = new int[16];//
        private int[] u1xsync_i;// = new int[16];// 
        private int[] u1ysync_i;// = new int[16];// 
        private uint[,] u1xpos;// = new uint[16, 16 * 4 * 1200]; //channels*timestamps per period*periods in max time
        private uint[,] u1ypos;// = new uint[16, 16 * 4 * 1200];
        private uint[,] u1xsync_timestamps;// = new uint[16, 16 * 4 * 1200];
        private uint[,] u1ysync_timestamps;// = new uint[16, 16 * 4 * 1200];
        private uint[,] u1xgsync_timestamps;// = new uint[16, 16 * 4 * 1200];
        private uint[,] u1ygsync_timestamps;// = new uint[16, 16 * 4 * 1200];

        private int[,] angleCount = new int[4, n_sens];
        private double[,] angleMean = new double[4, n_sens];
        private double[,] angleSum = new double[4, n_sens];
        private double[,] angleSumSq = new double[4, n_sens];
        private double[,] angleVar = new double[4, n_sens];
        private double[,] angleStdDev = new double[4, n_sens];
        private int[,] anglePrevCount = new int[4, n_sens];
        private double[,] anglePrevMean = new double[4, n_sens];
        private double[,] anglePrevSum = new double[4, n_sens];
        private double[,] anglePrevSumSq = new double[4, n_sens];
        private double[,] anglePrevVar = new double[4, n_sens];
        private double[,] anglePrevStdDev = new double[4, n_sens];

        private System.Collections.Generic.List<bool> u0ootx_data = new System.Collections.Generic.List<bool>();
        private System.Collections.Generic.List<bool> u1ootx_data = new System.Collections.Generic.List<bool>();

        uint[] timeDiff;
        private System.Text.StringBuilder rxData = new System.Text.StringBuilder();
        private int n_gsens;

        private int j0 = 3000;
        private int j1 = 4000;
        private int j2 = 5000;
        private int j3 = 6000;

        private int k0 = 3500;
        private int k1 = 4500;
        private int k2 = 5500;
        private int k3 = 6500;

        private int wordlength = 16;
        private int minLaser = 100;
        private int maxLaser = 1000;
        private int ootx_margin = 150;
        private double sampFreq = 48000000.0;

        private System.Windows.Forms.DataVisualization.Charting.Series[] pdSeries = new System.Windows.Forms.DataVisualization.Charting.Series[32];
        private System.Windows.Forms.DataVisualization.Charting.Series[] pdSeriesx = new System.Windows.Forms.DataVisualization.Charting.Series[32];
        private System.Windows.Forms.DataVisualization.Charting.Series[] pdSeriesy = new System.Windows.Forms.DataVisualization.Charting.Series[32];
        private System.Drawing.Color[] pdColor = new System.Drawing.Color[32];
        private System.Windows.Forms.DataVisualization.Charting.Series nopSeries = new System.Windows.Forms.DataVisualization.Charting.Series("No sensors detected");
        bool[] sensorDetected = new bool[32];
        bool[] xRotor = new bool[32];
        //bool xRotor;
        bool[] first_timestampr = new bool[32];
        bool[] first_timestampf = new bool[32];
        private System.UInt32[] last_timestampr = new System.UInt32[32];
        private System.UInt32[] last_timestampf = new System.UInt32[32];
        private System.UInt32[] last_timestamprr = new System.UInt32[32];
        private System.UInt32[] last_timestampff = new System.UInt32[32];
        private int[] seriesCount = new int[32];
        int nSensorsDetected;
        int selectedSeries = -1;
        //string selectedSeries = string.Empty;

        private System.Windows.Forms.GroupBox comGroupBox;
        private System.Windows.Forms.ComboBox comComboBox;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox graphGroupBox;
        private System.Windows.Forms.Label recTimeLabel;
        private System.Windows.Forms.Button testButton;
        private System.IO.Ports.SerialPort serialPort1;
        private System.Windows.Forms.TextBox sampleTextBox;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button clearConsoleButton;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Label runningLabel;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem editToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem helpToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem userInfoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem aboutToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem themeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem duskToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem formalToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem syncToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem firstEdgeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem averageToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem minMaxAvgToolStripMenuItem;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.ToolStripMenuItem exportToolStripMenuItem;
        private System.Windows.Forms.Label sensDetLabel;
        private System.Windows.Forms.DataVisualization.Charting.Chart chart1;
        private System.Windows.Forms.CheckBox rotorCheckBox;
        private System.Windows.Forms.RadioButton singleRadioButton;
        private System.Windows.Forms.RadioButton allRadioButton;
        private System.Windows.Forms.Label label3;
    }
}

